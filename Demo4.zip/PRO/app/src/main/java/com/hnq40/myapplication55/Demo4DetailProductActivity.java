package com.hnq40.myapplication55;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class Demo4DetailProductActivity extends AppCompatActivity {
    ImageView imageView;
    TextView tvStyleId,tvBrand,tvPrice,tvAddInfo;
    Intent intent;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo4_detail_product);
        imageView = findViewById(R.id.demo4ImageView);
        tvStyleId=findViewById(R.id.demo4TvStyleId);
        tvBrand=findViewById(R.id.demo4TvBrand);
        tvPrice=findViewById(R.id.demo4TvPrice);
        tvAddInfo=findViewById(R.id.demo4TvAddInfo);
        //nhan intent chuyen sang tu product lisst
         intent=getIntent();
         //doc product dinh kem intent
        Product product=intent.getParcelableExtra("PRODUCT");
        //doc du lieu tung thanh phan
        if(product!=null){
            //doc anh
            Picasso.get().load(product.getSearchImage())
                    .into(imageView);
            //doc cac truong khac
            tvStyleId.setText("Style ID: "+ product.getStyleId());
            tvBrand.setText("Brand: "+product.getBrand());
            tvPrice.setText("Price: "+product.getPrice());
            tvAddInfo.setText("Add info: "+product.getAddInfo());
        }

    }
}