package com.hnq40.myapplication55;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class ProductAdapter extends BaseAdapter {
    private Context mContext;
    private List<Product> mList;
    //ham khoi tao
    public ProductAdapter(Context mContext, List<Product> mList) {
        this.mContext = mContext;
        this.mList = mList;
    }
    //lay ve tong so item
    @Override
    public int getCount() {
        return mList.size();
    }
    //tra ve 1 item
    @Override
    public Object getItem(int position) {
        return mList.get(position);
    }
    //tra ve ID
    @Override
    public long getItemId(int position) {
        return position;
    }
    //tao view + gan du lieu
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        //1. Tao view
        if(convertView==null)//neu chua co view thi tao view moi
        {
            //tao view trang
            convertView= LayoutInflater.from(mContext)
                    .inflate(R.layout.demo3_itemview,parent,false);
            //anh xa tung thanh phan
            holder=new ViewHolder();
            holder.imageView=convertView.findViewById(R.id.demo3_itemview_image);
            holder.styleIdTv=convertView.findViewById(R.id.demo3_itemview_styleIdTv);
            holder.brandTv=convertView.findViewById(R.id.demo3_itemview_brandTv);
            holder.priceTv=convertView.findViewById(R.id.demo3_itemview_priceTv);
            holder.addInfoTv=convertView.findViewById(R.id.demo3_itemview_addInfoTv);
            //tao template de lan sau su dung
            convertView.setTag(holder);
        }
        else //neu da co view thi su dung view cu
        {
            holder=(ViewHolder) convertView.getTag();//lay ve template da ton tai
        }
        //2. gan du lieu
        Product product=mList.get(position);
        if(product!=null){
            //gan anh
            Picasso.get().load(product.getSearchImage())
                    .into(holder.imageView);
            //gan cac truong du lieu khac
            holder.styleIdTv.setText(product.getStyleId());
            holder.brandTv.setText(product.getBrand());
            holder.priceTv.setText(product.getPrice());
            holder.addInfoTv.setText(product.getAddInfo());
        }
        return convertView;
    }
    static class ViewHolder {
        ImageView imageView;
        TextView styleIdTv,brandTv,priceTv,addInfoTv;
    }
}
