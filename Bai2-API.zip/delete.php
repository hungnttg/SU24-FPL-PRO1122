<?php
//khai bao thong tin server
$ser="localhost"; $u="root"; $p="";$db="a3";
//thuc hien ket noi voi CSDL
$conn=new mysqli($ser,$u,$p,$db);
//khai bao tham so truyen
$MaSV=$_GET['MaSV'];
//$TenSV=$_GET['TenSV'];
//$Lop=$_GET['Lop'];
//khai bao lenh insert
//$sql="INSERT INTO Sinhvien VALUES ('$MaSV','$TenSV','$Lop')";
$sql="DELETE FROM Sinhvien WHERE MaSV='$MaSV'";
//cach goi: 
//http://localhost/000/202407/delete.php?MaSV=PH0003
//thuc thi insert
if($conn->query($sql))//thuc thi insert
{
    echo "xoa thanh cong";
}
else
{
    echo "Loi: ".$conn->error;
}
//dong ket noi
$conn->close();
//dau cham: ->
//ham print: echo
//noi chuoi .