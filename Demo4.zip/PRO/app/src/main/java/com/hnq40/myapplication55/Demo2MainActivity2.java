package com.hnq40.myapplication55;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class Demo2MainActivity2 extends AppCompatActivity {
    EditText txt1,txt2,txt3;
    Button btn1;
    TextView tv1;
    Context context=this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo2_main2);
        txt1=findViewById(R.id.demo12Txt1);
        txt2=findViewById(R.id.demo21Txt2);
        txt3=findViewById(R.id.demo21Txt3);
        tv1=findViewById(R.id.demo21Tv1);
        btn1=findViewById(R.id.demo21Btn1);
        btn1.setOnClickListener(v->{
            //1.khoi tao request
            RequestQueue queue= Volley.newRequestQueue(context);
            //2.url
            String MaSV=txt1.getText().toString();
            String TenSV=txt2.getText().toString();
            String Lop=txt3.getText().toString();
            String url="http://10.82.0.248/000/202407/insert.php?MaSV="+MaSV
                    +"&TenSV="+TenSV+"&Lop="+Lop;
            //StringRequest(phuongThuc,url,ThanhCong,ThatBai)
            StringRequest getRequest=new StringRequest(Request.Method.GET, url,
                    //thanh cong
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            tv1.setText("Insert thanh cong");
                        }
                    }, new Response.ErrorListener() {
                //that bai
                @Override
                public void onErrorResponse(VolleyError error) {
                    tv1.setText(error.getMessage());
                }
            });
            //4.thuc thi request
            queue.add(getRequest);
        });
    }
}