package com.hnq40.myapplication55;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Demo3MainActivity extends AppCompatActivity {
    private ListView listView;
    private ProductAdapter adapter;
    private List<Product> list;
    private Context context=this;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo3_main);
        listView=findViewById(R.id.demo3Lv);
        list=new ArrayList<>();
        adapter=new ProductAdapter(this,list);
        listView.setAdapter(adapter);

        //lay du lieu tu server
        new FetchProductTask().execute();
    }
    private class FetchProductTask extends AsyncTask<Void,Void,String>{
        //doc du lieu tu server
        @Override
        protected String doInBackground(Void... voids) {
            //tao bo chua du lieu doc tu server
            StringBuilder res=new StringBuilder();
            try {
                //URL doc du lieu
                URL url=new URL("https://hungnttg.github.io/shopgiay.json");
                //Tao ket noi
                HttpURLConnection connection=(HttpURLConnection) url.openConnection();
                //xac dinh phuong thuc doc du lieu
                connection.setRequestMethod("GET");
                //tao bo dem doc du lieu
                BufferedReader reader=new BufferedReader(new InputStreamReader(connection.getInputStream()));
                //doc theo dong
                String line="";
                while ((line=reader.readLine())!=null){//neu dong doc khong phai la null
                    res.append(line);//dua dong doc vao ket qua
                }
                //dong ket noi
                reader.close();
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            return res.toString();//tra ve ket qua doc duoc
        }
        //tra ket qua cho client
        @Override
        protected void onPostExecute(String res) {
            if(res!=null && !res.isEmpty()){//neu ket qua khac null hoac khac dau ""
                try {
                    JSONObject json=new JSONObject(res);//lay ve doi doi tuong json
                    JSONArray proArray=json.getJSONArray("products");//lay ve mang
                    for(int i=0;i<proArray.length();i++){//doc cac doi tuong trong mang
                        JSONObject pObject=proArray.getJSONObject(i);//lay ve 1 doi tuong
                        //lay ve cac truong cua doi tuong
                        String styleid=pObject.getString("styleid");
                        String brand=pObject.getString("brands_filter_facet");
                        String price=pObject.getString("price");
                        String addInfo=pObject.getString("product_additional_info");
                        String searchImage=pObject.getString("search_image");
                        //tao doi tuong voi cac truong du lieu doc duoc
                        Product p1=new Product(styleid,brand,price,addInfo,searchImage);
                        //them doi tuong vao list
                        list.add(p1);
                    }
                    adapter.notifyDataSetChanged();
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}